jQuery(function(){
	jQuery('.headermenu ul').slicknav({
		label: "",
		prependTo: ".mobilemenu"
	});
});

function scrolldesktopmenu() {
	jQuery('.headermenu').singlePageNav({
		offset: jQuery('.headermenu').outerHeight(),
		threshold: 120,
		speed: 800,
		currentClass: 'current',
		easing: 'swing',
		filter: ':not(.external)',
		Hash: true,
		beforeStart: function() {
		console.log('begin scrolling');
		},
		onComplete: function() {
		console.log('done scrolling');
		}
	});
}

function scrollmobilemenu() {
	jQuery('.mobilemenu').singlePageNav({
		offset: 0,
		threshold: 120,
		speed: 800,
		currentClass: 'current',
		easing: 'swing',
		filter: ':not(.external)',
		Hash: true,
		beforeStart: function() {
		console.log('begin scrolling');
		},
		onComplete: function() {
		console.log('done scrolling');
		}
	});
}



// After document is ready
jQuery(document).ready(function(){
	if (jQuery(window).width() < 768 ) {
		scrollmobilemenu();
	} else {
		scrolldesktopmenu();
	}
});

jQuery(window).resize(function(){
	if (jQuery(window).width() < 768 ) {
		scrollmobilemenu();
	} else {
		scrolldesktopmenu();
	}
});

// After Window loaded completely
jQuery(window).load(function (){
	jQuery('.banner.flexslider').flexslider({
		animation: "slide",
		prevText: "",           //String: Set the text for the "previous" directionNav item
		nextText: "",
		controlNav: false,
		slideshow: false
	});
	jQuery('.feedbackslider.flexslider').flexslider({
		animation: "slide",
		prevText: "",
		nextText: "",
		controlNav: false,
		slideshow: false
	});

});